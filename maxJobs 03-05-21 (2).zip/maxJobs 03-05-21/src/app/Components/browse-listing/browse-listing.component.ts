import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-browse-listing',
  templateUrl: './browse-listing.component.html',
  styleUrls: ['./browse-listing.component.css']
})
export class BrowseListingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
